<?php

namespace App\Contract\Hi_FPT;

interface RenderDeeplinkInterface
{
    public function index();
    public function store($params);
}
