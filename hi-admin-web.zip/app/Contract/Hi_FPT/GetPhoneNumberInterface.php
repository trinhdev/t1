<?php

namespace App\Contract\Hi_FPT;

interface GetPhoneNumberInterface
{
    public function index();
    public function store($params);
}
